package profilesinfo;

class Game {
    private Player playerA;
    private Player playerB;

    public Game(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
    }

    public void startGame() {
        Player attacker = playerA.getHealth() <= playerB.getHealth() ? playerA : playerB;
        Player defender = attacker == playerA ? playerB : playerA;

        while (attacker.isAlive() && defender.isAlive()) {
            int attackDamage = attacker.getAttack() * attacker.attackRoll();
            int defenseDamage = defender.getStrength() * defender.defendRoll();
            int damageDealt = Math.max(0, attackDamage - defenseDamage);
            defender.reduceHealth(damageDealt);
            System.out.println("Player " + (attacker == playerA ? "A" : "B") +
                               " attacks! Damage: " + damageDealt + ", " +
                               "Defender's health: " + defender.getHealth());

            
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        if (!attacker.isAlive()) {
            System.out.println("Player " + (attacker == playerA ? "A" : "B") + " wins!");
        }
    }
}
