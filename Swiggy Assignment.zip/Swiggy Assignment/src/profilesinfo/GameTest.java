package profilesinfo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GameTest {

	@Test
	public void testPlayerHealthReduction() {
        Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);
        
        playerA.reduceHealth(30);
        assertEquals(20, playerA.getHealth());
    }
	@Test
    public void testPlayerIsAlive() {
        Player playerA = new Player(50, 5, 10);
        assertTrue(playerA.isAlive());
        
        playerA.reduceHealth(50);
        assertFalse(playerA.isAlive());
    }
	@Test
    public void testAttackAndDefense() {
        Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);
        
        Game game = new Game(playerA, playerB);
        game.startGame();
        assertTrue(playerB.getHealth() < 100);  
    }
}
